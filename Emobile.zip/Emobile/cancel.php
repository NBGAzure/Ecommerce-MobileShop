<?php
include_once("connection.php");
include_once("header.php");
?>
<style>

.choosing-plan {
    padding: 200px 0;
}
</style>

</section>
<section class="choosing-plan">
  <div class="container">
    <div class="row">
      <div class="col-md-3 col-sm-3"></div>
      <div class="col-md-6 col-sm-6">
        <div class="alert alert-warning">
          <strong>Cancel !</strong> Sorry, Your order was cancelled Please Try Again!!
        </div>
      </div>
      <div class="col-md-3 col-sm-3"></div>
    </div>
  </div>
</section>
    
    

<?php
include_once("footer.php");
?>